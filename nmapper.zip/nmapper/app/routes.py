from flask import Blueprint, render_template, request, jsonify, current_app
from app.scanner import NetworkScanner
from app.models import Scan, Host
from app import db

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/scan', methods=['POST'])
def start_scan():
    scanner = NetworkScanner(current_app._get_current_object())
    network = request.form.get('network')
    scan_id = scanner.start_scan(network)
    return jsonify({'scan_id': scan_id})

@main.route('/scan/<int:scan_id>/status')
def scan_status(scan_id):
    scan = Scan.query.get_or_404(scan_id)
    return jsonify({
        'status': scan.status,
        'current_phase': scan.current_phase,
        'hosts': [{
            'ip': host.ip_address,
            'status': host.status,
            'hostname': host.hostname,
            'ports': [{
                'number': port.port_number,
                'protocol': port.protocol,
                'state': port.state,
                'service': port.service,
                'version': port.version,
                'scripts': [{
                    'name': script.script_name,
                    'output': script.script_output
                } for script in port.script_results]
            } for port in host.open_ports]
        } for host in scan.hosts]
    })

@main.route('/results')
def results():
    scans = Scan.query.order_by(Scan.timestamp.desc()).all()
    return render_template('results.html', scans=scans) 