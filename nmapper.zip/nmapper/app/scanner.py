import nmap
from app.models import Scan, Host, Port, ScriptResult
from app import db
import threading
from flask import current_app
import ipaddress

class NetworkScanner:
    def __init__(self, app=None):
        self.nm = nmap.PortScanner()
        self.app = app
    
    def is_single_host(self, target):
        try:
            # Remove any whitespace
            target = target.strip()
            
            # Check if it's a CIDR notation
            if '/' in target:
                network = ipaddress.ip_network(target, strict=False)
                return network.num_addresses == 1
            
            # Try to parse as IP address
            try:
                ipaddress.ip_address(target)
                return True
            except ValueError:
                # If not an IP, check if it's a hostname
                # If there's no slash and it's not an IP, assume it's a single host
                return '/' not in target
            
        except Exception as e:
            print(f"Error checking target type: {str(e)}")
            # If we can't determine, assume it's not a single host
            return False

    def detailed_host_scan(self, host_ip, is_single=False):
        """Perform detailed scan on a single host"""
        try:
            if is_single:
                # For single host, do a more thorough scan with common NSE scripts
                self.nm.scan(host_ip, arguments='-sT -sV --script=default,vuln')
            else:
                # For hosts in network scan, do basic service detection
                self.nm.scan(host_ip, arguments='-sT -sV')
            
            result = {
                'os_guess': '',
                'ports': []
            }
            
            if 'tcp' in self.nm[host_ip]:
                for port_number, port_data in self.nm[host_ip]['tcp'].items():
                    port_info = {
                        'port_number': port_number,
                        'protocol': 'tcp',
                        'state': port_data['state'],
                        'service': port_data.get('name', ''),
                        'version': port_data.get('version', ''),
                        'scripts': []
                    }
                    
                    # Get script results if available
                    if 'script' in port_data:
                        for script_name, output in port_data['script'].items():
                            port_info['scripts'].append({
                                'name': script_name,
                                'output': output
                            })
                    
                    result['ports'].append(port_info)
            
            return result
        except Exception as e:
            print(f"Error scanning host {host_ip}: {str(e)}")
            return None

    def scan_network(self, network, scan_id):
        with self.app.app_context():
            scan = Scan.query.get(scan_id)
            is_single = self.is_single_host(network)
            
            try:
                # Initial discovery scan
                scan.current_phase = "Host Discovery"
                db.session.commit()
                self.nm.scan(hosts=network, arguments='-sn')
                
                # Process each discovered host
                for host_ip in self.nm.all_hosts():
                    if self.nm[host_ip].state() == 'up':
                        scan.current_phase = f"Port scanning {host_ip}"
                        if is_single:
                            scan.current_phase = f"Running detailed scan on {host_ip}"
                        db.session.commit()
                        
                        hostname = ''
                        if 'hostname' in self.nm[host_ip]:
                            hostname = self.nm[host_ip]['hostname']
                        
                        # Create host entry
                        host_entry = Host(
                            scan_id=scan_id,
                            ip_address=host_ip,
                            status=self.nm[host_ip].state(),
                            hostname=hostname
                        )
                        db.session.add(host_entry)
                        db.session.commit()
                        
                        # Perform detailed scan on the host
                        detailed_results = self.detailed_host_scan(host_ip, is_single)
                        if detailed_results:
                            # Update host with OS information
                            host_entry.os_guess = detailed_results['os_guess']
                            
                            # Add port information
                            for port_info in detailed_results['ports']:
                                port_entry = Port(
                                    host_id=host_entry.id,
                                    port_number=port_info['port_number'],
                                    protocol=port_info['protocol'],
                                    service=port_info['service'],
                                    version=port_info['version'],
                                    state=port_info['state']
                                )
                                db.session.add(port_entry)
                                db.session.commit()
                                
                                # Add script results if available
                                for script in port_info.get('scripts', []):
                                    script_entry = ScriptResult(
                                        port_id=port_entry.id,
                                        script_name=script['name'],
                                        script_output=script['output']
                                    )
                                    db.session.add(script_entry)
                
                scan.status = 'completed'
                db.session.commit()
                
            except Exception as e:
                scan.status = 'failed'
                db.session.commit()
                raise e

    def start_scan(self, network):
        scan = Scan(network=network)
        db.session.add(scan)
        db.session.commit()
        
        thread = threading.Thread(
            target=self.scan_network,
            args=(network, scan.id)
        )
        thread.start()
        
        return scan.id