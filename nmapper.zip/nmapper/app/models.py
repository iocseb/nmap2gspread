from app import db
from datetime import datetime

class Scan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    network = db.Column(db.String(50), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='running')
    current_phase = db.Column(db.String(100))
    hosts = db.relationship('Host', backref='scan', lazy=True)

class Host(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scan_id = db.Column(db.Integer, db.ForeignKey('scan.id'), nullable=False)
    ip_address = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), nullable=False)
    hostname = db.Column(db.String(100))
    os_guess = db.Column(db.String(200))
    open_ports = db.relationship('Port', backref='host', lazy=True)

class Port(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    host_id = db.Column(db.Integer, db.ForeignKey('host.id'), nullable=False)
    port_number = db.Column(db.Integer, nullable=False)
    protocol = db.Column(db.String(10), nullable=False)
    service = db.Column(db.String(50))
    version = db.Column(db.String(100))
    state = db.Column(db.String(20), nullable=False)
    script_results = db.relationship('ScriptResult', backref='port', lazy=True)

class ScriptResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    port_id = db.Column(db.Integer, db.ForeignKey('port.id'), nullable=False)
    script_name = db.Column(db.String(100), nullable=False)
    script_output = db.Column(db.Text) 